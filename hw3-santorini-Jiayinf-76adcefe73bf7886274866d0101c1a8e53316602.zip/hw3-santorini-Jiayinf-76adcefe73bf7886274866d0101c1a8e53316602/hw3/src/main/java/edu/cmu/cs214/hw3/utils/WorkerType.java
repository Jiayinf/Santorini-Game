package edu.cmu.cs214.hw3.utils;

public enum WorkerType {
    TYPE_A, TYPE_B, TYPE_TEST
}
